package com.example.demo.datafetchers;

import com.example.demo.generated.types.Claim;
import com.example.demo.generated.types.Participant;
import com.example.demo.generated.types.Review;
import com.example.demo.generated.types.Show;
import com.netflix.graphql.dgs.DgsComponent;
import com.netflix.graphql.dgs.DgsData;
import com.netflix.graphql.dgs.DgsDataFetchingEnvironment;
import com.netflix.graphql.dgs.DgsEntityFetcher;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@DgsComponent
public class ClaimsDatafetcher {

     Map<String, List<Participant>> participants = new HashMap<>();


    public ClaimsDatafetcher() {

        List<Participant> claim1 = new ArrayList<>();
        claim1.add(new Participant("1","1","1"));
        claim1.add(new Participant("2","1","2"));
        participants.put("1", claim1);

        List<Participant> claim2 = new ArrayList<>();
        claim2.add(new Participant("4","1","4"));
        claim2.add(new Participant("5","1","2"));
        participants.put("2", claim2);
    }

    @DgsEntityFetcher(name = "Claim")
    public Claim movie(Map<String, Object> values) {
        return new Claim((String) values.get("id"), null,null);
    }

    @DgsData(parentType = "Claim", field = "participants")
    public List<Participant> participantsFetcher(DgsDataFetchingEnvironment dataFetchingEnvironment)  {
        Claim claim = dataFetchingEnvironment.getSource();
        return participants.get(claim.getId());
    }

    @DgsData(parentType = "Claim", field = "retrieveParticipant" )
    public List<Participant> participantFetcher(DgsDataFetchingEnvironment dataFetchingEnvironment)  {
        Claim claim = dataFetchingEnvironment.getSource();
        //Participant participant = dataFetchingEnvironment.getSource();
        //System.out.println("==================>"+participant.toString());
        return participants.get(claim.getId());
    }
}
